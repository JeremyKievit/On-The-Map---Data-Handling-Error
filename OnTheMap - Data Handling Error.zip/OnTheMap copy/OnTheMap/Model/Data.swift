//
//  StudentModel.swift
//  OnTheMap
//
//  Created by admin on 11/18/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation
import MapKit

class Data {
    static var studentList = [PinData]()
    static var MKPointAnnotations = [MKPointAnnotation]()
    
    struct Auth {
        static var objectId: String = ""
        static var userId: String = ""
    }
    
    struct User {
        static var firstName: String = ""
        static var lastName: String = ""
        static var latitude: Double = 0.0
        static var longitude: Double = 0.0
        static var mapString: String = ""
        static var mediaURL: String = ""
        static var coordinate: CLLocationCoordinate2D? = nil
    }
}
