//
//  PostLocationVC.swift
//  OnTheMap
//
//  Created by admin on 11/19/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import UIKit
import MapKit

class PostLocationVC: UIViewController {
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setPinData()
    }
    
    @IBAction func backButton(_ sender: Any) {
        DispatchQueue.main.async {
          self.dismiss(animated: false, completion: nil)
        }
    }
    
    @IBAction func confirmPin(_ sender: Any) {
        OTMClient.createStudentLocation(completion: handleCreateLocationResponse(success:error:))

            DispatchQueue.main.async {
                self.presentingViewController!.presentingViewController!.dismiss(animated: true, completion: nil)
            }
    }
    
    func setPinData() {
        guard let coordinate = Data.User.coordinate else {
            print("coordinate data unavailable")
            print(Data.User.coordinate as Any)
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Error", message: "Location posting failed", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
                 alert.dismiss(animated: true, completion: nil)
                }))
                self.present(alert, animated: true, completion: nil)
            }
            return
        }
        print("coordinate data retrieved")
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = Data.User.mapString
        
        let region = MKCoordinateRegion(center: coordinate, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        DispatchQueue.main.async {
            self.mapView.addAnnotation(annotation)
            self.mapView.setRegion(region, animated: true)
            self.mapView.regionThatFits(region)
        }
    }
    
    func handleCreateLocationResponse(success: Bool, error: Error?) {
        if success == false {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Error", message: "Location posting failed", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
                 alert.dismiss(animated: true, completion: nil)
                }))
                self.present(alert, animated: true, completion: nil)
            }
            return
        }
    }
}

