//
//  StudentMapVC.swift
//  OnTheMap
//
//  Created by admin on 11/9/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class StudentMapVC: UIViewController {
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView!.delegate = self
        OTMClient.getStudentLocations(completion: handleDataResponse(data:error:))
    }
    
    func handleDataResponse(data: [PinData]?, error: Error?) {
        guard let data = data else {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Error", message: "Could not access user data", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            return
        }
        if error != nil {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Could not access user data", message: "\(error!)", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            return
        }

        let locations = data
        var pinData = [MKPointAnnotation]()

        for location in locations {
            let lat = CLLocationDegrees(location.latitude ?? 0)
            let long = CLLocationDegrees(location.longitude ?? 0)
            let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
            
            let first = location.firstName
            let last = location.lastName
            let mediaURL = location.mediaURL
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = "\(first ?? "") \(last ?? "")"
            annotation.subtitle = mediaURL
            
            pinData.append(annotation)
        }
        self.mapView.addAnnotations(pinData)
    }

}

extension StudentMapVC: MKMapViewDelegate {
    
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            let reuseId = "pin"
            var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

            if pinView == nil {
                pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
                pinView!.canShowCallout = true
                pinView!.pinTintColor = .red
                pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            } else {
                pinView!.annotation = annotation
            }
            
            return pinView
        }

        func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
            if control == view.rightCalloutAccessoryView {
                let app = UIApplication.shared
                if let toOpen = view.annotation?.subtitle! {
                    app.open(URL(string: toOpen)!, options: [:], completionHandler: nil)
                }
            }
        }
    
        func mapView(mapView: MKMapView, annotationView: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
    
            if control == annotationView.rightCalloutAccessoryView {
                let app = UIApplication.shared
                let url = NSURL(string: annotationView.annotation!.subtitle!!)! as URL
                app.open(url, options: [:], completionHandler: nil)
            }
        }
}
